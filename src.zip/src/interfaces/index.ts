export interface ITodoListItem {
    id: number;
    title: string;
    description: string;
}